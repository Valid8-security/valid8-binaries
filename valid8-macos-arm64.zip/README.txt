Valid8 Security Scanner - macOS (ARM64)

Installation:
1. Extract this zip file
2. Make executable: chmod +x valid8
3. Move to PATH: sudo mv valid8 /usr/local/bin/
4. Run: valid8 --help

Or run directly: ./valid8 scan /path/to/code
