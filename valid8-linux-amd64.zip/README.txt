Valid8 Binary - Coming Soon

This binary is currently being built and will be available soon.

For now, please use the macOS binary or check back later.

Visit: https://github.com/Valid8-security/valid8-binaries
