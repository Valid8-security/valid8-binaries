Valid8 Security Scanner - Windows (AMD64)

Installation:
1. Extract this zip file
2. Run: valid8.exe --help

Or add to PATH for system-wide access.
